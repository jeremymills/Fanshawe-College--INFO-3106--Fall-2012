<?php
define('IN_APPLICATION', true);

ini_set('display_errors','on');
error_reporting(E_ALL | E_STRICT);

// ========================================
// define absolute path of mini-application
define('ABS_PATH', dirname(__FILE__) . DIRECTORY_SEPARATOR);

require_once ABS_PATH . 'bootstrap.php';

// =====================================
// initiate boolean variables
$errors = array();

/**
 * add.php form
 */ 
$fields = array('title'=>'', 'message'=>'');
$t = '';
$m = '';

if( isset( $_POST['save']) ) {
	$fields['title'] = isset($_POST['title']) ? strip_tags(stripslashes(trim($_POST['title']))) : $fields['title'];
	$fields['message'] = isset($_POST['message']) ? strip_tags(stripslashes(trim($_POST['message']))) : $fields['message'];
	
	if( empty($fields['title']) ) {
		$errors[] = 'The title field is requird.';
	} else {
		$t = $fields['title'];
	}
	if( empty($fields['message']) ) {
		$errors[] = 'The message field is required.';
	} else {
		$m = $fields['message'];
	}
	
	if( empty($errors) ) {
		// Good! validation seems to be OK!
		// Time to perform some sort of success routine.. mail? save to be? etc.
		
		$date = new DateTime(null);
		$d = $date->getTimestamp();
		
		$insert = $mysqli->prepare("INSERT INTO notes (created, title, message) VALUES(?,?,?)");
		if( $insert ) {
			$insert->bind_param('dss',$d,$t,$m);
			$insert->execute();
			
			$fields['title'] = $t;
			$fields['message'] = $m;
			
			$noteID = $mysqli->insert_id;
		}
		$insert->close();
	}
}
  
?>
<html !DOCTYPE>
<head>
<title>PHP MySQL</title>
	<style>
		body { background-color: grey; font-family: "Helvetica", Arial, sans-serif; font-size: 13px; color: #333; }
		
		#error { background: #ff0000; padding: 1px 5px; color: #fff; border-radius: 10px;}
		
		#wrap { width: 600px; margin: 70px auto 30px auto; background-color: #fff; border: 1px solid grey; border-radius: 25px; }
		#content { width: 600px; margin: 10px auto 30px auto; background-color: #fff; border: 1px solid grey; border-radius: 25px; }
		#content h3 { margin-top: 5px; text-align: center;}
		
		#info { padding: 10px; }
		
		h1 { border-bottom: 4px solid grey; width: 360px; margin-left: 0; padding: 0 0 0 7px; }
		h2 { margin-left: 0; padding-left: 7px; width: 250px; border-bottom: 4px solid grey;}
		
		table { margin-top: 40px; }
		table a { text-decoration: none; }
		table th { color: green; }
		table td { padding: 15px 5px 10px 35px; }
		
		.back { margin-top: 50px; padding: 5px;}
		.save { margin-top: 50px; margin-left: 260px; padding: 5px 20px 5px 20px;}
		.add { margin-top: 50px; margin-right: 0; padding: 5px;}
		footer { color: grey; clear: both; padding: 10px 10px 20px 0; height: 15px; text-align: right;}
		
		form { margin-top:-4px;padding:0; }
	</style>
</head>
<body>
	<div id="wrap">
		<h1>Assignment 9 PSA</h1>
		<h2>Add Note</h2>
	</div>
	<form id="content" method="post">
			<?php if( empty($errors) ) : ?>
			<h3>Title:*<input type="text" name="title" value="<?php print $t;?>"/></h3>
				<div id="info">
					<p>Message:*<textarea name="message" id="message" cols="69" rows="5"><?php print $m;?></textarea></p>
					
				</div>
				<input type="submit" class="save" name="save" value="Save" onclick="return(confirm('Are You Sure?'))"/>
				<?php else :?>
				<div id="error">
					<?php 
					if( !empty($errors) ) {
						foreach( $errors as $error ) { ?>
							<p><strong>Error: </strong><em><?php print $error; ?></em></p>
					<?php }//endforeach
					}//end if ?>
				</div>
		
		<button class="save" onclick="add.php">Back</button>
		<?php endif; ?>
	<footer id="footer">
		<p><em>&copy Copyright Jeremy Mills</em></p>
	</footer>
	</div><!--end content form-->
	<p style="margin-left: 20px; margin-top: -27px;"><a href="index.php">Back to Notes</a></p>
	<?php if( isset($_POST['save']) && empty($errors) ) : ?>
	<p style="margin-left: 130px; margin-top: -29px;"><a href="viewnote.php?id=<?php print $noteID;?>">View Created Note</a></p>
	<?php endif; ?>
</body>
</html>