<?php
/*
 * @ignore
 */
defined('IN_APPLICATION') or exit;

return array(
	'db_host' => 'localhost',
	'db_user' => 'root',
	'db_pass' => 'adminroot',
	'db_name' => 'lamp1_finalexam_jjrm'
);

