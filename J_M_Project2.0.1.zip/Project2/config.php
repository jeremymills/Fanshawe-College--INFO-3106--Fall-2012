<?php
/*
 * @ignore
 */
defined('IN_APPLICATION') or exit;

return array(
	'db_host' => '127.0.0.1',
	'db_user' => 'root',
	'db_pass' => 'password',
	'db_name' => 'lamp1_project2_jjrm'
);

